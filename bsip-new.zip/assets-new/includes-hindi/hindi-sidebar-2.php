<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <p class="sidebar-heading">संरचना</p>
    </li>
    <li><a href="hindi-governing-body.php"><i class="fas fa-landmark"></i> शासी मंडल</a></li>
    <li><a href="hindi-research-advisory-council.php"><i class="fas fa-lightbulb"></i> अनुसंधान सलाहकार परिषद</a></li>
    <li><a href="hindi-finance-committee.php"><i class="fas fa-coins"></i> वित्त समिति</a></li>
    <li><a href="hindi-building-committee.php"><i class="fas fa-building"></i> भवन समिति</a></li>
    <li><a href="hindi-director.php"><i class="fas fa-user-tie"></i> निदेशक</a></li>
    <li><a href="hindi-organizational-setup.php"><i class="fas fa-sitemap"></i> संगठनात्मक व्यवस्था</a></li>
    <li><a href="hindi-past-heads.php"><i class="fas fa-users-cog"></i> संस्थान के पूर्व-प्रमुख</a></li>
    <li><a href="hindi-past-president-chairman.php"><i class="fas fa-user-shield"></i> पूर्व सभापति/अध्यक्ष</a></li>
  </ul>
</div>