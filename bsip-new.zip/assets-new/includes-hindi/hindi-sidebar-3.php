<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <p class="sidebar-heading">संरचना</p>
    </li>
    <li><a href="hindi-director-staff.php"><i class="fas fa-user-tie"></i> निदेशक</a></li>
    <li><a href="hindi-scientific.php"><i class="fas fa-flask"></i> वैज्ञानिक</a></li>
    <li><a href="hindi-technical.php"><i class="fas fa-cogs"></i> तकनीकी</a></li>
    <li><a href="hindi-administrative.php"><i class="fas fa-briefcase"></i> प्रशासनिक</a></li>
    <li><a href="hindi-superannuated.php"><i class="fas fa-user-clock"></i> वयोवृद्ध</a></li>
  </ul>
</div>