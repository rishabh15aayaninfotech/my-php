<section class="wrapper carousel-wrapper">
  <div class="container common-container four_content carousel-container">
    <div id="flexCarousel" class="flexslider carousel">
      <ul class="slides">
        <li>
          <a target="_blank" href="http://digitalindia.gov.in/"
            title="Digital India, External Link that opens in a new window"><img
              src="assets-new/assets/images/carousel/digital-india.png" alt="Digital India"></a>
        </li>
        <li>
          <a target="_blank" href="http://www.makeinindia.com/"
            title="Make In India, External Link that opens in a new window"> <img
              src="assets-new/assets/images/carousel/makeinindia.png" alt="Make In India"></a>
        </li>
        <li>
          <a target="_blank" href="http://india.gov.in/"
            title="National Portal of India, External Link that opens in a new window"><img
              src="assets-new/assets/images/carousel/india-gov.png" alt="National Portal of India"></a>
        </li>
        <li>
          <a target="_blank" href="http://goidirectory.nic.in/"
            title="GOI Web Directory, External Link that opens in a new window"><img
              src="assets-new/assets/images/carousel/goidirectory.png" alt="GOI Web Directory"></a>
        </li>
        <li>
          <a target="_blank" href="https://data.gov.in/"
            title="Data portal, External Link that opens in a new window"><img
              src="assets-new/assets/images/carousel/data-gov.png" alt="Data portal"></a>
        </li>
        <li>
          <a target="_blank" href="https://mygov.in/" title="MyGov, External Link that opens in a new window"><img
              src="assets-new/assets/images/carousel/mygov.png" alt="MyGov Portal"></a>
        </li>
      </ul>
    </div>
  </div>
</section>