<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <p class="sidebar-heading">प्रोफाइल</p>
    </li>
    <li><a href="hindi-history.php"><i class="fas fa-history"></i> इतिहास</a></li>
    <li><a href="hindi-parental-background.php"><i class="fas fa-users"></i> पैरेंटल पृष्ठभूमि</a></li>
    <li><a href="hindi-education-career.php"><i class="fas fa-graduation-cap"></i> शिक्षा कैरियर</a></li>
    <li><a href="hindi-general-interest.php"><i class="fas fa-heart"></i> सामान्य हित</a></li>
    <li><a href="hindi-incident-of-youth.php"><i class="fas fa-exclamation-triangle"></i> युवावस्था की घटना</a></li>
    <li><a href="hindi-honours.php"><i class="fas fa-award"></i> सम्मान</a></li>
    <li><a href="hindi-living.php"><i class="fas fa-home"></i> जीविका</a></li>
    <li><a href="hindi-fossil.php"><i class="fas fa-bone"></i> जीवाश्म</a></li>
    <li><a href="hindi-geology.php"><i class="fas fa-mountain"></i> भूगर्भ शास्त्र</a></li>
    <li><a href="hindi-mrs-savitri-sahni.php"><i class="fas fa-user-alt"></i> श्रीमती सावित्री साहनी</a></li>
  </ul>
</div>