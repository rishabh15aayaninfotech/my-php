<header>
        <div class="region region-header-top">
            <div id="block-cmf-content-header-region-block" class="block block-cmf-content first last odd">
                <!-- <noscript class="no_scr">"JzavaScript is a standard programming language that is included to provide
               interactive features, Kindly enable Javascript in your browser. For details visit help page"
            </noscript> -->
                <div class="wrapper common-wrapper">
                    <div class="container common-container four_content top-header">
                        <div class="common-left clearfix">
                            <ul>
                                <!--<li class="gov-india"><span class="responsive_go_hindi" lang="hi"><a target="_blank"-->
                                <!--         href="https://india.gov.in/hi"-->
                                <!--         title="भारत सरकार ( बाहरी वेबसाइट जो एक नई विंडो में खुलती है)" role="link">भारत-->
                                <!--         सरकार</a></span> </li>-->
                                <!--<li class="ministry"><span class="li_eng responsive_go_eng"><a target="_blank"-->
                                <!--         href="https://india.gov.in/"-->
                                <!--         title="Government of india,External Link that opens in a new window"-->
                                <!--         role="link">Government of india</a></span></li>-->
                                <!--<li class="ico-skip cf"><a href="#skipCont" title="">Skip to main content</a>-->
                                <!--</li>-->
                            </ul>
                        </div>
                        <div class="common-right clearfix">
                            <ul id="header-nav">
                                <li class="ico-skip cf"><a href="#skipCont" title="">मुख्य सामग्री पर जाएँ</a>
                                </li>
                                <li class="ico-skip cf"><a href="#" title="">स्क्रीन रीडर एक्सेस</a>
                                </li>
                                <li class="ico-site-search cf">
                                    <a href="javascript:void(0);" id="toggleSearch" title="Site Search" role="link">
                                        <img class="top" src="assets-new/assets/images/ico-site-search.png"
                                            alt="Site Search" /></a>
                                    <div class="search-drop both-search">
                                        <div class="google-find">
                                            <form method="get" action="http://www.google.com/search" target="_blank">
                                                <label for="search_key_g" class="notdisplay">Search</label>
                                                <input type="text" name="q" value="" id="search_key_g" />
                                                <input type="submit" value="Search" class="submit" />
                                                <div class="">
                                                    <input type="radio" name="sitesearch" value="" id="the_web" />
                                                    <label for="the_web">The Web</label>
                                                    <input type="radio" name="sitesearch" value="india.gov.in" checked
                                                        id="the_domain" />
                                                    <label for="the_domain"> INDIA.GOV.IN</label>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="find">
                                            <form name="searchForm" action="#">
                                                <label for="search_key" class="notdisplay">Search</label>
                                                <input type="text" name="search_key" id="search_key"
                                                    onKeyUp="autoComplete()" autocomplete="off" required />
                                                <input type="submit" value="Search" class="bttn-search" />
                                            </form>
                                            <div id="auto_suggesion"></div>
                                        </div>
                                    </div>
                                </li>
                                <li class="ico-accessibility cf">
                                    <a href="javascript:void(0);" id="toggleAccessibility"
                                        title="Accessibility Dropdown" role="link">
                                        <img class="top" src="assets-new/assets/images/ico-accessibility.png"
                                            alt="Accessibility Dropdown" />
                                    </a>
                                    <ul style="visibility: hidden;">
                                        <li> <a onClick="set_font_size(&#39;increase&#39;)" title="Increase font size"
                                                href="javascript:void(0);" role="link">A<sup>+</sup>
                                            </a>
                                        </li>
                                        <li> <a onClick="set_font_size()" title="Reset font size"
                                                href="javascript:void(0);" role="link">A<sup>&nbsp;</sup></a> </li>
                                        <li> <a onClick="set_font_size(&#39;decrease&#39;)" title="Decrease font size"
                                                href="javascript:void(0);" role="link">A<sup>-</sup></a> </li>
                                        <li> <a href="javascript:void(0);" class="high-contrast dark"
                                                title="High Contrast" role="link">A</a> </li>
                                        <li> <a href="javascript:void(0);" class="high-contrast light"
                                                title="Normal Contrast" style="display: none;" role="link">A</a> </li>
                                    </ul>
                                </li>
                                <li class="ico-social cf">
                                    <a href="javascript:void(0);" id="toggleSocial" title="Social Medias" role="link">
                                        <img class="top" src="assets-new/assets/images/ico-social.png" alt="Social Medias" /></a>
                                    <ul>
                                        <li>
                                            <a target="_blank" title="External Link that opens in a new window"
                                                href="https://www.facebook.com/people/Birbal-Sahni-Institute-of-Palaeosciences/100064628684500/"><img
                                                    alt="Facebook Page" src="assets-new/assets/images/ico-facebook.png"></a>
                                        </li>
                                        <li>
                                            <a target="_blank" title="External Link that opens in a new window"
                                                href="https://twitter.com/BSIP_official"><img alt="Twitter Page"
                                                    src="assets-new/assets/images/ico-twitter.png"></a>
                                        </li>
                                        <li>
                                            <a target="_blank" title="External Link that opens in a new window"
                                                href="https://www.youtube.com/channel/UCeLoQeBr4NUD_ivaqnASeKg/videos"><img
                                                    alt="youtube Page" src="assets-new/assets/images/ico-youtube.png"></a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="ico-sitemap cf">
                                    <a href="#" title="Sitemap" role="link" aria-label="sitemap">
                                        <img class="top" src="assets-new/assets/images/ico-sitemap.png" alt="Sitemap" /></a>
                                </li>
                                <!-- Desktop Language Switcher (d-hide) -->
                                <li class="hindi cmf_lan d-hide">
                                    <label class="de-lag" for="language-select">
                                        <span>Language</span>
                                    </label>
                                    <select id="language-select" title="Select language">
                                        <option value="index.php">English</option>
                                        <option value="hindi-index.php" selected>हिन्दी</option>
                                    </select>
                                </li>

                                <!-- Mobile Language Switcher (m-hide) -->
                                <li class="hindi cmf_lan m-hide">
                                    <a href="javascript:;" title="Select Language">Language</a>
                                    <ul>
                                        <li>
                                            <a href="index.php" lang="en" class="alink"
                                                title="Click here for English version.">English</a>
                                        </li>
                                        <li>
                                            <a href="hindi-index.php" lang="hi" class="alink"
                                                title="Click here for हिन्दी version.">हिन्दी</a>
                                        </li>
                                    </ul>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <p id="scroll" style="display: none;"><span></span></p>
        </div>
        <!--Top-Header Section end-->
        <section class="wrapper header-wrapper">
            <div class="container-fluid common-container four_content header-container">
                <div class="row">
                    <div class="col-md-12 logo">
                        <a href="hindi-index.php" title="Home" rel="home" class="header__logo" id="logo">
                            <img class="national_emblem" src="assets-new/assets/images/bsip-logo.png" alt="national emblem">
                        </a>
                    </div>
                </div>
                <h1></h1>
                <!--<h1 class="logo">
               <a href="index.php" title="Home" rel="home" class="header__logo" id="logo">
                  <img class="national_emblem" src="assets/images/bsip-logo.png" alt="national emblem">
               </a>
            </h1>-->
                <!-- <div class="header-right clearfix">
               <div class="right-content clearfix">
                  <div class="float-element">
                     <a class="sw-logo" target="_blank" href="https://swachhbharat.mygov.in/"
                        title="Swachh Bharat, External link that open in a new windows"><img
                           src="assets/images/swach-bharat.png" alt="Swachh Bharat"></a>
                  </div>
               </div>
            </div> -->
            </div>
        </section>
        <!--/.header-wrapper-->
        <section class="wrapper megamenu-wraper">
            <div class="container-fluid common-container four_content">
                <p class="showhide"><em></em><em></em><em></em></p>
                <nav class="main-menu clearfix" id="main_menu">
                    <ul class="nav-menu">
                        <li class="nav-item"> <a href="hindi_index.php" class="home" role="link" aria-label="home"><span
                                    style="display: none;">Home</span><i class="fa fa-home"></i></a> </li>
                        <li class="nav-item">
                            <a href="#" role="link" aria-label="profile">प्रोफ़ाइल</a>
                            <div class="sub-nav">
                                <ul class="sub-nav-group">
                                    <li><a href="hin_bsip_institute_history.php" role="link"
                                            aria-label="history">इतिहास</a></li>
                                    <!-- <li class="dropdown"><a href="">Prof. Birbal Sahni</a>
                           </li> -->
                                    <li class="menu-item">
                                        <a href="#" class="menu-link" role="link" aria-label="Prof.">प्रो. बीरबल
                                            साहनी</a>
                                        <div class="dropdown-menu">
                                            <ul class="dropdown-list">
                                                <li><a href="hin_bsip_Prof_birbal_Sahni_background.php"
                                                        class="dropdown-item" role="link" aria-label="Biography">पैतृक
                                                        पृष्ठभूमि</a></li>
                                                <li><a href="hin_bsip_Prof_birbal_Sahni_education_career.php"
                                                        class="dropdown-item" role="link"
                                                        aria-label="Publications">शैक्षिक योग्यताएं</a></li>
                                                <li><a href="hin_bsip_Prof_birbal_Sahni_General_interest.php"
                                                        class="dropdown-item" role="link"
                                                        aria-label="Contributions">सामान्य रूचि</a></li>
                                                <li><a href="hin_bsip_Prof_birbal_Sahni_youth_incident.php"
                                                        class="dropdown-item" role="link" aria-label="Awards">युवाओं का
                                                        वृत्तांत</a></li>

                                                <li class="menu-item">
                                                    <a href="#" class="dropdown-item" role="link"
                                                        aria-label="contri">योगदान</a>
                                                    <div class="dropdown-menu">
                                                        <ul class="dropdown-list">
                                                            <li><a href="hin_bsip_contribution_living.php"
                                                                    class="dropdown-item" role="link"
                                                                    aria-label="living">जीविका</a></li>
                                                            <li><a href="hin_bsip_contribution_fossil.php"
                                                                    class="dropdown-item" role="link"
                                                                    aria-label="fossil">जीवाश्म</a></li>
                                                            <li><a href="hin_bsip_contribution_geology.php"
                                                                    class="dropdown-item" role="link"
                                                                    aria-label="geology">भूगर्भ विज्ञान</a></li>
                                                        </ul>
                                                    </div>
                                                </li>
                                    </li>
                                    <li><a href="hin_bsip_institute_honours.php" class="dropdown-item" role="link"
                                            aria-label="Research-Projects">सम्मान</a></li>
                                </ul>
                            </div>
                        </li>

                        <li><a href="hin_bsip_institute_mrs_savitri_sahni.php" role="link" aria-label="home">श्रीमती
                                सावित्री
                                साहनी</a></li>

                    </ul>
            </div>
            </li>
            <li class="nav-item">
                <a href="#" role="link" aria-label="home">संरचना</a>
                <div class="sub-nav">
                    <ul class="sub-nav-group">
                        <li><a href="bsip_governing_body.php" role="link" aria-label="home">शासी मंडल</a></li>
                        <li><a href="hin_bsip_research_advisory_council.php" role="link" aria-label="home">अनुसंधान
                                सलाहकार परिषद</a></li>
                        <li><a href="hin_bsip_finance_and_building_committee.php" role="link" aria-label="home">वित्त
                                एवं भवन
                                समिति</a></li>
                        <li><a href="hin_director.php" role="link" aria-label="home">निदेशक</a></li>
                        <li><a href="hin_bsip_organizational_setup.php" role="link" aria-label="home">संगठनात्मक
                                व्यवस्था</a></li>
                        <li><a href="bsip_past_institute_heads.php" role="link" aria-label="home">संस्थान के
                                पुर्व-प्रमुख</a></li>
                        <li><a href="hin_bsip_past_institute_presidents.php" role="link" aria-label="home">पूर्व
                                सभापति/अध्यक्ष</a></li>

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a href="#" role="link" aria-label="home">स्टाफ़</a>
                <div class="sub-nav">
                    <ul class="sub-nav-group">
                        <li><a href="hin_director.php" role="link" aria-label="home">निदेशक</a></li>
                        <li><a href="hin_bsip_scientific.php" role="link" aria-label="home">वैज्ञानिक</a></li>
                        <li><a href="hin_bsip_technical_staff.php" role="link" aria-label="home">तकनीकी</a></li>
                        <li><a href="hin_bsip_administrative.php" role="link" aria-label="home">प्रशासनिक</a></li>
                        <li><a href="hin_bsip_superannuated_employee.php" role="link" aria-label="home">वयोवृद्ध</a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a href="#" role="link" aria-label="home">अनुसंधान</a>
                <div class="sub-nav">
                    <ul class="sub-nav-group">
                        <li><a href="hin_bsip_research_activities.php" role="link" aria-label="home">अनुसंधान
                                गतिविधियाँ</a>
                        </li>
                        <li><a href="hin_bsip_collaboration.php" role="link" aria-label="home">सहयोग</a></li>
                        <li><a href="hin_bsip_sponsored_project.php" role="link" aria-label="home">प्रायोजित
                                परियोजनाएं</a>
                        </li>
                        <li><a href="hin_bsip_fellowship.php" role="link" aria-label="home">फेलोशिप</a></li>
                        <li><a href="hin_bsip_medals_and_awards.php" role="link" aria-label="home">Medals & Awards</a>
                        </li>
                        <li><a href="hin_bsip_lectures.php" role="link" aria-label="home">Lectures</a></li>
                        <li><a href="hin_bsip_consultancy.php" role="link" aria-label="home">Consultancy</a></li>

                    </ul>
                </div>
            </li>

            <li class="nav-item">
                <a href="#" role="link" aria-label="home">प्रकाशन</a>
                <div class="sub-nav">
                    <ul class="sub-nav-group">
                        <li><a href="hin_bsip_the_paleobotanist.php" role="link" aria-label="home">जर्नल ऑफ
                                पैलियोसाइंसेज</a></li>
                        <li><a href="hin_bsip_annual_reports.php" role="link" aria-label="home">वार्षिक विवरणिका</a>
                        </li>
                        <li><a href="hin_bsip_catalogues.php" role="link" aria-label="home">केटलौग/मोनोग्राफ</a></li>
                        <li><a href="hin_bsip_p_on__sale.php" role="link" aria-label="home">प्रकाशन विक्रय</a></li>
                        <li><a href="hin_bsip_research_highlights_all.php" role="link" aria-label="home">शोध पत्र</a>
                        </li>
                        <li><a href="hin_bsip_monthly_report.php" role="link" aria-label="home">मासिक रिपोर्ट</a></li>
                        <li><a href="hin_bsip_newsletter.php" role="link" aria-label="home">समाचार पत्रिका</a></li>
                    </ul>
                </div>
            </li>

            <li class="nav-item">
                <a href="#" role="link" aria-label="home">इकाईयां</a>
                <div class="sub-nav">
                    <ul class="sub-nav-group">
                        <li><a href="hin_bsip_museum.php" role="link" aria-label="home">संग्रहालय</a></li>
                        <li><a href="hin_bsip_library.php" role="link" aria-label="home">ज्ञान संसाधन केंद्र</a></li>
                        <li><a href="hin_bsip_computer_section.php" role="link" aria-label="home">कंप्यूटर अनुभाग</a>
                        </li>
                        <li><a href="hin_bsip_geo_heritage.php" role="link" aria-label="home">भू-विरासत एवं भू-पर्यटन
                                संवर्धन केंद्र
                                (सीपीजीजी)</a></li>
                        <li><a href="hin_hin_bsip_amber_analysis.php" role="link" aria-label="home">एम्बर विश्लेषण और
                                पैलियोएंटोमोलॉजी
                                प्रयोगशाला</a></li>

                    </ul>
                </div>
            </li>
            <li class="nav-item"><a href="hin_bsip_tender.php" role="link" aria-label="home">निविदा</a></li>
            <li class="nav-item">
                <a href="#" role="link" aria-label="home">रोजगार</a>
                <div class="sub-nav col-1">
                    <ul class="sub-nav-group ">
                        <li><a href="https://bsiprecruitment.in/" role="link" aria-label="home" target="_blank">बीएसआईपी
                                भर्ती पोर्टल</a></li>
                        <li><a href="hin_bsip_career.php" role="link" aria-label="home">विज्ञापन</a></li>
                        <li><a href="hin_bsip_admission_to_phd.php" role="link" aria-label="home">पीएच.डी. कार्यक्रम में
                                प्रवेश</a></li>
                        <li><a href="hin_bsip_master_dissertation_program.php" role="link" aria-label="home">बीरबल साहनी
                                बीएसआईपी में
                                द्विवार्षिक स्नातकोत्तर शोध प्रबंध कार्यक्रम</a></li>
                        <li><a href="hin_bsip_short_term_training_program.php" role="link" aria-label="home">अनुसंधान
                                विद्वानों,
                                स्नातकोत्तर और स्नातक छात्रों के लिए बीरबल साहनी प्रशिक्षण कार्यक्रम</a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a href="#" role="link" aria-label="home">सुविधाएं</a>
                <div class="sub-nav col-1">
                    <ul class="sub-nav-group ">
                        <li><a href="saif.php" role="link" aria-label="home">सैफ</a></li>
                        <li><a href="hin_bsip_dna_lab.php" role="link" aria-label="home">डीएनए लैब</a></li>
                        <li><a href="hin_bsip_sem.php" role="link" aria-label="home">एफ.ई.एस.ई.एम.</a></li>
                        <li><a href="hin_bsip_c14.php" role="link" aria-label="home">सी 14</a></li>
                        <li><a href="hin_bsip_section_cutting.php" role="link" aria-label="home">सेक्शन कटिंग</a></li>
                        <li><a href="hin_bsip_maceration.php" role="link" aria-label="home">Maceration</a></li>

                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a href="#" role="link" aria-label="home">आयोजन</a>
                <div class="sub-nav col-1">
                    <ul class="sub-nav-group ">
                        <li><a href="https://www.inquaindia2027.in/" role="link" aria-label="home" target="_blank">XXII
                                INQUA 2027</a></li>
                        <li><a href="IAS_BSIP_Circular.pdf" role="link" aria-label="home" target="_blank">आईएएस का 40वां
                                सम्मेलन-2024</a></li>
                        <li><a href="hin_LEM_ISS_2023.php" role="link" aria-label="home">एलईएम-आईएसएस-2023</a></li>
                        <li><a href="hin_bsip_gallery.php" role="link" aria-label="home">फोटो गैलरी</a></li>
                        <li><a href="hin_bsip_past_events.php" role="link" aria-label="home">विगत आयोजन</a></li>

                    </ul>
                </div>
            </li>

            <li class="nav-item"><a href="hin_bsip_rajbhasha_patal.php" role="link" aria-label="home">राजभाषा पटल</a>
            </li>
            <!--<li class="nav-item"><a href="#" role="link" aria-label="home">Others</a></li>-->
            </ul>
            </nav>

            <nav class="main-menu clearfix" id="overflow_menu">
                <ul class="nav-menu clearfix">
                </ul>
            </nav>
            </div>
            <style type="text/css">
                body~.sub-nav {
                    right: 0
                }
            </style>
        </section>
    </header>