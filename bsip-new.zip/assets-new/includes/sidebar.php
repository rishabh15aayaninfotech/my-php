<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <h2 class="sidebar-heading">Profile</h2>
    </li>
    <li><a href="history.php"><i class="fas fa-history"></i>History</a></li>
    <li><a href="parental-background.php"><i class="fas fa-users"></i>Parental Background</a></li>
    <li><a href="education-career.php"><i class="fas fa-graduation-cap"></i>Education Career</a></li>
    <li><a href="general-interest.php"><i class="fas fa-heart"></i>General Interest</a></li>
    <li><a href="incident-of-youth.php"><i class="fas fa-exclamation-triangle"></i>Incident of Youth</a></li>
    <li><a href="honours.php"><i class="fas fa-award"></i>Honours</a></li>
    <li><a href="living.php"><i class="fas fa-home"></i>Living</a></li>
    <li><a href="fossil.php"><i class="fas fa-bone"></i>Fossil</a></li>
    <li><a href="geology.php"><i class="fas fa-mountain"></i>Geology</a></li>
    <li><a href="mrs-savitri-sahni.php"><i class="fas fa-user-alt"></i>Mrs. Savitri Sahni</a></li>
  </ul>
</div>