<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <h2 class="sidebar-heading">Publications</h2>
    </li>
    <li><a href="palaeosciences.php"><i class="fas fa-book"></i> Journal of Palaeosciences</a></li>
    <li><a href="annual-reports.php"><i class="fas fa-file-alt"></i> Annual Reports</a></li>
    <li><a href="catalogues.php"><i class="fas fa-list"></i> Catalogues</a></li>
    <li><a href="publications-on-sale.php"><i class="fas fa-shopping-cart"></i> Publications On Sale</a></li>
    <li><a href="research-highlights-all.php"><i class="fas fa-scroll"></i> Research Papers</a></li>
    <li><a href="monthly-report.php"><i class="fas fa-calendar-alt"></i> Monthly Report</a></li>
    <li><a href="newsletter.php"><i class="fas fa-envelope-open-text"></i> Newsletter</a></li>
    <li><a href="e-magazine.php"><i class="fas fa-tablet-alt"></i> E-Magazine</a></li>
  </ul>
</div>