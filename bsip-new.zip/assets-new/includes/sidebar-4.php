<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <h2 class="sidebar-heading">Research</h2>
    </li>
    <li><a href="research-activities.php"><i class="fas fa-atom"></i> Research Activities</a></li>
    <li><a href="collaborations.php"><i class="fas fa-handshake"></i> Collaborations</a></li>
    <li><a href="sponsored-projects.php"><i class="fas fa-money-check-alt"></i> Sponsored Projects</a></li>
    <li><a href="fellowships.php"><i class="fas fa-graduation-cap"></i> Fellowship</a></li>
    <li><a href="medals-and-awards.php"><i class="fas fa-award"></i> Medals & Awards</a></li>
    <li><a href="lectures.php"><i class="fas fa-chalkboard-teacher"></i> Lectures</a></li>
    <li><a href="consultancy.php"><i class="fas fa-user-tie"></i> Consultancy</a></li>
  </ul>
</div>
