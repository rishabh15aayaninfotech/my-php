<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <h2 class="sidebar-heading">Staff</h2>
    </li>
    <li><a href="staff-director.php"><i class="fas fa-user-tie"></i> Director</a></li>
    <li><a href="scientific.php"><i class="fas fa-microscope"></i> Scientific</a></li>
    <li><a href="technical-staff.php"><i class="fas fa-tools"></i> Technical</a></li>
    <li><a href="administrative.php"><i class="fas fa-briefcase"></i> Administrative</a></li>
    <li><a href="superannuated-employee.php"><i class="fas fa-user-clock"></i> Superannuated</a></li>
    <li><a href="acsir-staff.php"><i class="fas fa-book-open"></i> AcSIR</a></li>
  </ul>
</div>
