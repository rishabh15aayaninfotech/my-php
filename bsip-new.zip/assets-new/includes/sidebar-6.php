<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <h2 class="sidebar-heading">Units</h2>
    </li>
    <li><a href="museum.php"><i class="fas fa-landmark"></i> Museum</a></li>
    <li><a href="knowledge-resource-centre.php"><i class="fas fa-book-reader"></i> Knowledge Resource Centre</a></li>
    <li><a href="computer-section.php"><i class="fas fa-desktop"></i> Computer Section</a></li>
    <li><a href="cpgg.php"><i class="fas fa-globe"></i> Centre for Promotion of Geoheritage and Geotourism (CPGG)</a></li>
    <li><a href="amber-lab.php"><i class="fas fa-microscope"></i> Amber Analysis and Palaeoentomology Laboratory</a></li>
  </ul>
</div>
