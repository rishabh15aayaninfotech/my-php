<section class="wrapper banner-wrapper">
  <div id="flexSlider" class="flexslider">
    <ul class="slides">
      <li> <img src="https://www.bsip.res.in/slide/Slide1.JPG" alt="slide 1"></li>
      <li> <img src="https://www.bsip.res.in/slide/Slide2.JPG" alt="slide 2"></li>
      <li> <img src="https://www.bsip.res.in/slide/Slide3.JPG" alt="slide 3"></li>
      <li> <img src="https://www.bsip.res.in/admin/assets/pdf-file/SLI56131730199678.JPG" alt="slide 4"></li>
      <li> <img src="https://www.bsip.res.in/admin/assets/pdf-file/SLI62641730199654.JPG" alt="slide 5"></li>
    </ul>
  </div>
</section>