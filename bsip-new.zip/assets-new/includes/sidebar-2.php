<div class="col-md-3 sidebar">
  <ul class="sidebar-nav">
    <li>
      <h2 class="sidebar-heading">Structure</h2>
    </li>
    <li><a href="governing-body.php"><i class="fas fa-landmark"></i>Governing Body</a></li>
    <li><a href="research-advisory-council.php"><i class="fas fa-lightbulb"></i>Research Advisory Council</a></li>
    <li><a href="finance-committee.php"><i class="fas fa-coins"></i>Finance Committee</a></li>
    <li><a href="building-committee.php"><i class="fas fa-building"></i>Building Committee</a></li>
    <li><a href="director.php"><i class="fas fa-user-tie"></i>Director</a></li>
    <li><a href="organizational-setup.php"><i class="fas fa-sitemap"></i>Organizational Setup</a></li>
    <li><a href="past-heads.php"><i class="fas fa-users-cog"></i>Past Heads of Institute</a></li>
    <li><a href="past-president-chairman.php"><i class="fas fa-user-shield"></i>Past President/Chairman</a></li>
  </ul>
</div>